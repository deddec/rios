using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.IO;

namespace FlowerShop.Server.Data;

/// <summary>
/// Управление подключением к базе данных MSSQL (ЛР № 8).
/// Предоставляет создание соединения, проверку доступности,
/// создание базы и применение схемы из schema.sql.
/// </summary>
public sealed class Database : IDisposable
{
    private readonly string _connectionString;
    private readonly string _databaseName;
    private readonly string _masterConnectionString;
    private SqlConnection? _connection;
    private bool _disposed;

    /// <summary>Путь к файлу схемы базы данных.</summary>
    public string SchemaPath { get; }

    /// <summary>Имя базы данных.</summary>
    public string DatabaseName => _databaseName;

    /// <summary>Текущее соединение (null, если не открыто).</summary>
    public SqlConnection? Connection => _disposed ? null : _connection;

    public Database(string? connectionString = null, string? schemaPath = null)
    {
        _connectionString = connectionString ??
            Environment.GetEnvironmentVariable("FlowerShop__DbConnectionString") ??
            "Server=db,1433;Database=FlowerShop;User=sa;Password=YourStrong!Passw0rd;TrustServerCertificate=True;";

        _databaseName = ExtractDatabaseName(_connectionString) ?? "FlowerShop";
        _masterConnectionString = BuildMasterConnectionString(_connectionString);

        SchemaPath = schemaPath ?? Path.Combine(AppContext.BaseDirectory, "Data", "schema.sql");
        if (!File.Exists(SchemaPath))
        {
            var projectRoot = Directory.GetParent(AppContext.BaseDirectory)?.Parent?.Parent?.Parent;
            var candidate = projectRoot != null
                ? Path.Combine(projectRoot.FullName, "Server", "Data", "schema.sql")
                : null;
            if (candidate != null && File.Exists(candidate))
                SchemaPath = candidate;
        }
    }

    /// <summary>Проверка доступности базы данных.</summary>
    public bool TryPing(out string? error)
    {
        error = null;
        try
        {
            using var conn = new SqlConnection(_masterConnectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT 1";
            cmd.ExecuteScalar();
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    /// <summary>Создать базу данных, если она не существует.</summary>
    public bool EnsureDatabaseExists(out string? error)
    {
        error = null;
        try
        {
            using var conn = new SqlConnection(_masterConnectionString);
            conn.Open();

            using var checkCmd = conn.CreateCommand();
            checkCmd.CommandText = $"SELECT database_id FROM sys.databases WHERE name = N'{_databaseName}'";
            var exists = checkCmd.ExecuteScalar() != null;

            if (!exists)
            {
                using var createCmd = conn.CreateCommand();
                createCmd.CommandText = $"CREATE DATABASE [{_databaseName}]";
                createCmd.ExecuteNonQuery();
            }

            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    /// <summary>Применить схему из файла schema.sql.</summary>
    public bool EnsureSchema(out string? error)
    {
        error = null;
        try
        {
            if (!File.Exists(SchemaPath))
            {
                error = $"Файл схемы не найден: {SchemaPath}";
                return false;
            }

            var sql = File.ReadAllText(SchemaPath);
            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            foreach (var batch in SplitByGo(sql))
            {
                if (string.IsNullOrWhiteSpace(batch)) continue;
                using var cmd = conn.CreateCommand();
                cmd.CommandText = batch;
                cmd.ExecuteNonQuery();
            }

            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    /// <summary>Открыть соединение с базой данных.</summary>
    public SqlConnection OpenConnection()
    {
        if (_disposed) throw new ObjectDisposedException(nameof(Database));
        _connection = new SqlConnection(_connectionString);
        _connection.Open();
        return _connection;
    }

    /// <summary>Получить новое соединение (для использования в using).</summary>
    public SqlConnection CreateConnection() => new SqlConnection(_connectionString);

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try { _connection?.Close(); } catch { }
        _connection?.Dispose();
    }

    // ---- приватные helpers -------------------------------------------------

    private static string? ExtractDatabaseName(string connectionString)
    {
        try
        {
            var builder = new SqlConnectionStringBuilder(connectionString);
            return string.IsNullOrWhiteSpace(builder.InitialCatalog) ? null : builder.InitialCatalog;
        }
        catch { return null; }
    }

    private static string BuildMasterConnectionString(string connectionString)
    {
        try
        {
            var builder = new SqlConnectionStringBuilder(connectionString)
            {
                InitialCatalog = "master"
            };
            return builder.ConnectionString;
        }
        catch { return connectionString; }
    }

    private static IEnumerable<string> SplitByGo(string sql)
    {
        var lines = new List<string>();
        var current = new System.Text.StringBuilder();
        foreach (var line in sql.Split('\n'))
        {
            var trimmed = line.Trim();
            if (string.Equals(trimmed, "GO", StringComparison.OrdinalIgnoreCase))
            {
                lines.Add(current.ToString());
                current.Clear();
            }
            else
            {
                current.AppendLine(line);
            }
        }
        if (current.Length > 0)
            lines.Add(current.ToString());
        return lines;
    }
}