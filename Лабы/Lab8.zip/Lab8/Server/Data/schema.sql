-- Схема базы данных для ЛР № 8 (вариант 14 — Заказ и доставка цветов)
-- Применяется к базе FlowerShop через Database.EnsureSchema()

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Customers')
CREATE TABLE Customers (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(200) NOT NULL,
    Phone NVARCHAR(50) NOT NULL
);
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Bouquets')
CREATE TABLE Bouquets (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL,
    TotalPrice DECIMAL(18,2) NOT NULL DEFAULT 0,
    AvailableCount INT NOT NULL DEFAULT 0
);
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'FlowerItems')
CREATE TABLE FlowerItems (
    Id INT PRIMARY KEY IDENTITY(1,1),
    BouquetId INT NOT NULL REFERENCES Bouquets(Id) ON DELETE CASCADE,
    FlowerName NVARCHAR(100) NOT NULL,
    Count INT NOT NULL DEFAULT 0,
    PricePerUnit DECIMAL(18,2) NOT NULL DEFAULT 0
);
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Florists')
CREATE TABLE Florists (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Specialization NVARCHAR(200) NOT NULL DEFAULT '',
    IsAvailable BIT NOT NULL DEFAULT 1
);
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Orders')
CREATE TABLE Orders (
    Id INT PRIMARY KEY IDENTITY(1,1),
    CustomerId INT NOT NULL REFERENCES Customers(Id),
    BouquetId INT NOT NULL REFERENCES Bouquets(Id),
    DeliveryDate DATETIME2 NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Created',
    FloristId INT NULL REFERENCES Florists(Id),
    DeliveryAddress NVARCHAR(500) NOT NULL DEFAULT '',
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'OrderEvents')
CREATE TABLE OrderEvents (
    Id INT PRIMARY KEY IDENTITY(1,1),
    OrderId INT NOT NULL REFERENCES Orders(Id) ON DELETE CASCADE,
    EventType NVARCHAR(100) NOT NULL,
    EventId NVARCHAR(100) NOT NULL,
    SequenceNumber BIGINT NOT NULL DEFAULT 0,
    Timestamp DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    ClientId INT NULL,
    Data NVARCHAR(MAX) NULL
);
GO

-- Демо-данные
INSERT INTO Customers (Name, Email, Phone) VALUES
('Иван Иванов', 'ivan@example.com', '+7-900-000-00-01'),
('Мария Петрова', 'maria@example.com', '+7-900-000-00-02');

INSERT INTO Bouquets (Name, TotalPrice, AvailableCount) VALUES
('Новогодний люкс', 2500.00m, 5),
('Весенний свежесть', 1800.00m, 3),
('Романтический', 3200.00m, 2);

INSERT INTO FlowerItems (BouquetId, FlowerName, Count, PricePerUnit) VALUES
(1, 'Розы', 15, 100.00m),
(1, 'Лилии', 5, 150.00m),
(2, 'Тюльпаны', 20, 60.00m),
(2, 'Нарциссы', 10, 80.00m),
(3, 'Пионы', 12, 200.00m);

INSERT INTO Florists (Name, Specialization, IsAvailable) VALUES
('Елена Смирнова', 'Свадебные букеты', 1),
('Алексей Волков', 'Корпоративная оформка', 1);
GO