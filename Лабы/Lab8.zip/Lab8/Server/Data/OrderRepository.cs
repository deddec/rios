using System.Collections.Concurrent;
using FlowerShop.Shared.Models;
using FlowerShop.Shared.PubSub;
using Microsoft.Data.SqlClient;

namespace FlowerShop.Server.Data;

/// <summary>
/// Репозиторий заказов с постоянным хранением в MSSQL (ЛР № 8).
/// Все заказы из предметной области «Заказ и доставка цветов» сохраняются в БД.
/// Поддерживает CRUD-операции и получение статистики.
/// </summary>
public sealed class OrderRepository : IDisposable
{
    private readonly Database _db;
    private bool _disposed;

    /// <summary>Все заказы в памяти (кэш, синхронизированный с БД).</summary>
    private readonly ConcurrentDictionary<int, Order> _orders = new();

    public OrderRepository(Database db)
    {
        _db = db ?? throw new ArgumentNullException(nameof(db));
        _disposed = false;
    }

    /// <summary>Создать заказ в БД и вернуть его с присвоенным Id.</summary>
    public Order Create(Order order)
    {
        if (order is null) throw new ArgumentNullException(nameof(order));

        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
INSERT INTO Orders (CustomerId, BouquetId, DeliveryDate, Status, FloristId, DeliveryAddress, CreatedAt)
OUTPUT INSERTED.Id, INSERTED.CustomerId, INSERTED.BouquetId, INSERTED.DeliveryDate,
       INSERTED.Status, INSERTED.FloristId, INSERTED.DeliveryAddress, INSERTED.CreatedAt
VALUES (@CustomerId, @BouquetId, @DeliveryDate, @Status, @FloristId, @DeliveryAddress, SYSDATETIME())";
        cmd.Parameters.AddWithValue("@CustomerId", order.CustomerId);
        cmd.Parameters.AddWithValue("@BouquetId", order.BouquetId);
        cmd.Parameters.AddWithValue("@DeliveryDate", order.DeliveryDate);
        cmd.Parameters.AddWithValue("@Status", order.Status);
        cmd.Parameters.AddWithValue("@FloristId", (object?)order.FloristId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@DeliveryAddress", order.DeliveryAddress);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read())
            throw new InvalidOperationException("Не удалось создать заказ в БД");

        order.Id = reader.GetInt32(0);
        order.CustomerId = reader.GetInt32(1);
        order.BouquetId = reader.GetInt32(2);
        order.DeliveryDate = reader.GetDateTime(3);
        order.Status = reader.GetString(4);
        order.FloristId = reader.IsDBNull(5) ? null : reader.GetInt32(5);
        order.DeliveryAddress = reader.GetString(6);

        _orders[order.Id] = order;
        return order;
    }

    /// <summary>Получить заказ по Id (сначала из кэша, затем из БД).</summary>
    public Order? GetById(int orderId)
    {
        if (_orders.TryGetValue(orderId, out var cached)) return cached;

        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id, CustomerId, BouquetId, DeliveryDate, Status, FloristId, DeliveryAddress FROM Orders WHERE Id = @Id";
        cmd.Parameters.AddWithValue("@Id", orderId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;

        var order = ReadOrder(reader);
        _orders[orderId] = order;
        return order;
    }

    /// <summary>Обновить заказ (статус, флорист, адрес).</summary>
    public bool Update(Order order)
    {
        if (order is null) throw new ArgumentNullException(nameof(order));
        if (order.Id <= 0) return false;

        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
UPDATE Orders
SET Status = @Status, FloristId = @FloristId, DeliveryAddress = @DeliveryAddress
WHERE Id = @Id";
        cmd.Parameters.AddWithValue("@Id", order.Id);
        cmd.Parameters.AddWithValue("@Status", order.Status);
        cmd.Parameters.AddWithValue("@FloristId", (object?)order.FloristId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@DeliveryAddress", order.DeliveryAddress);

        var rows = cmd.ExecuteNonQuery();
        if (rows > 0 && _orders.ContainsKey(order.Id))
            _orders[order.Id] = order;

        return rows > 0;
    }

    /// <summary>Обновить только статус заказа.</summary>
    public bool UpdateStatus(int orderId, string status)
    {
        var order = GetById(orderId);
        if (order is null) return false;

        order.Status = status;
        return Update(order);
    }

    /// <summary>Удалить заказ по Id.</summary>
    public bool Delete(int orderId)
    {
        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM Orders WHERE Id = @Id";
        cmd.Parameters.AddWithValue("@Id", orderId);

        var rows = cmd.ExecuteNonQuery();
        _orders.TryRemove(orderId, out _);
        return rows > 0;
    }

    /// <summary>Получить все заказы.</summary>
    public IReadOnlyList<Order> GetAll()
    {
        if (_orders.Count > 0)
            return _orders.Values.OrderBy(o => o.Id).ToList();

        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id, CustomerId, BouquetId, DeliveryDate, Status, FloristId, DeliveryAddress FROM Orders ORDER BY Id";

        using var reader = cmd.ExecuteReader();
        var list = new List<Order>();
        while (reader.Read())
        {
            var order = ReadOrder(reader);
            list.Add(order);
            _orders[order.Id] = order;
        }

        return list.OrderBy(o => o.Id).ToList();
    }

    /// <summary>Получить заказы по статусу.</summary>
    public IReadOnlyList<Order> GetByStatus(string status)
    {
        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id, CustomerId, BouquetId, DeliveryDate, Status, FloristId, DeliveryAddress FROM Orders WHERE Status = @Status ORDER BY Id";
        cmd.Parameters.AddWithValue("@Status", status);

        using var reader = cmd.ExecuteReader();
        var list = new List<Order>();
        while (reader.Read())
        {
            var order = ReadOrder(reader);
            list.Add(order);
            _orders[order.Id] = order;
        }

        return list.OrderBy(o => o.Id).ToList();
    }

    /// <summary>Получить количество заказов.</summary>
    public int Count()
    {
        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Orders";
        return Convert.ToInt32(cmd.ExecuteScalar());
    }

    /// <summary>Проверка, существует ли заказ с таким Id.</summary>
    public bool Exists(int orderId)
    {
        if (_orders.ContainsKey(orderId)) return true;

        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Orders WHERE Id = @Id";
        cmd.Parameters.AddWithValue("@Id", orderId);
        return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
    }

    /// <summary>Сохранить событие заказа в таблицу OrderEvents.</summary>
    public void SaveEvent(int orderId, string eventType, string eventId, long sequenceNumber, int? clientId, IDictionary<string, string>? data = null)
    {
        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
INSERT INTO OrderEvents (OrderId, EventType, EventId, SequenceNumber, ClientId, Data)
VALUES (@OrderId, @EventType, @EventId, @SequenceNumber, @ClientId, @Data)";
        cmd.Parameters.AddWithValue("@OrderId", orderId);
        cmd.Parameters.AddWithValue("@EventType", eventType);
        cmd.Parameters.AddWithValue("@EventId", eventId);
        cmd.Parameters.AddWithValue("@SequenceNumber", sequenceNumber);
        cmd.Parameters.AddWithValue("@ClientId", (object?)clientId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@Data", data is null || data.Count == 0 ? (object)DBNull.Value : System.Text.Json.JsonSerializer.Serialize(data));

        cmd.ExecuteNonQuery();
    }

    /// <summary>Получить события заказа.</summary>
    public IReadOnlyList<OrderEventRecord> GetEvents(int orderId)
    {
        using var conn = _db.CreateConnection();
        conn.Open();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT EventType, EventId, SequenceNumber, Timestamp, ClientId, Data FROM OrderEvents WHERE OrderId = @OrderId ORDER BY SequenceNumber";
        cmd.Parameters.AddWithValue("@OrderId", orderId);

        using var reader = cmd.ExecuteReader();
        var list = new List<OrderEventRecord>();
        while (reader.Read())
        {
            list.Add(new OrderEventRecord(
                reader.GetString(0),
                reader.GetString(1),
                reader.GetInt64(2),
                reader.GetDateTime(3),
                reader.IsDBNull(4) ? null : reader.GetInt32(4),
                reader.IsDBNull(5) ? null : reader.GetString(5)));
        }

        return list;
    }

    // ---- приватные helpers -------------------------------------------------

    private static Order ReadOrder(SqlDataReader reader)
    {
        return new Order
        {
            Id = reader.GetInt32(0),
            CustomerId = reader.GetInt32(1),
            BouquetId = reader.GetInt32(2),
            DeliveryDate = reader.GetDateTime(3),
            Status = reader.GetString(4),
            FloristId = reader.IsDBNull(5) ? (int?)null : reader.GetInt32(5),
            DeliveryAddress = reader.GetString(6)
        };
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
    }
}

/// <summary>Запись события заказа из БД.</summary>
public sealed record OrderEventRecord(
    string EventType,
    string EventId,
    long SequenceNumber,
    DateTime Timestamp,
    int? ClientId,
    string? Data);